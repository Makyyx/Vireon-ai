import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import PayPalButton from "../components/PayPalButton";

const PLANS = [
  {
    id: "starter" as const,
    name: "Starter",
    price: 14.99,
    priceLabel: "$14.99/mo",
    trial: "3-day free trial",
    features: ["2 uploads per week", "1 active series", "AI script generation", "Caption & hashtags", "Voiceover text", "Video frame export"],
    color: "from-blue-500 to-blue-700",
    border: "border-blue-500/30",
    ring: "ring-blue-500/50",
    badge: "bg-blue-900/50 text-blue-300",
  },
  {
    id: "growth" as const,
    name: "Growth",
    price: 24.99,
    priceLabel: "$24.99/mo",
    trial: null,
    features: ["4 uploads per week", "2 active series", "AI script generation", "Caption & hashtags", "Voiceover text", "Video frame export"],
    color: "from-purple-500 to-purple-700",
    border: "border-purple-500/30",
    ring: "ring-purple-500/50",
    badge: "bg-purple-900/50 text-purple-300",
    popular: true,
  },
  {
    id: "pro" as const,
    name: "Pro",
    price: 34.99,
    priceLabel: "$34.99/mo",
    trial: null,
    features: ["Daily uploads (7/week)", "3 active series", "AI script generation", "Caption & hashtags", "Voiceover text", "Video frame export"],
    color: "from-yellow-500 to-orange-600",
    border: "border-yellow-500/30",
    ring: "ring-yellow-500/50",
    badge: "bg-yellow-900/50 text-yellow-300",
  },
];

export default function Settings() {
  const user = useQuery(api.auth.loggedInUser);
  const profile = useQuery(api.userProfiles.getOrCreate);
  const subStatus = useQuery(api.payments.getSubscriptionStatus);
  const cancelSubscription = useMutation(api.payments.cancelSubscription);

  const [selectedPlan, setSelectedPlan] = useState<"starter" | "growth" | "pro" | null>(null);
  const [showPayPal, setShowPayPal] = useState(false);

  const currentPlan = profile?.plan ?? "free";

  const handleSelectPlan = (planId: "starter" | "growth" | "pro") => {
    if (planId === currentPlan) return;
    setSelectedPlan(planId);
    setShowPayPal(true);
  };

  const handleCancel = async () => {
    if (!confirm("Cancel your subscription? You'll be downgraded to the free plan.")) return;
    try {
      await cancelSubscription();
      toast.success("Subscription cancelled");
    } catch {
      toast.error("Failed to cancel subscription");
    }
  };

  const handlePaymentSuccess = () => {
    setShowPayPal(false);
    setSelectedPlan(null);
    toast.success("🎉 Plan upgraded successfully!");
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-1">Settings</h1>
        <p className="text-gray-400">Manage your account and subscription</p>
      </div>

      {/* Account Info */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">Account</h2>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-xl font-bold">
            {user?.email?.[0]?.toUpperCase() ?? "U"}
          </div>
          <div>
            <p className="text-white font-medium">{user?.email ?? "—"}</p>
            <p className="text-gray-500 text-sm">Member since {user ? new Date(user._creationTime).toLocaleDateString() : "—"}</p>
          </div>
        </div>
      </div>

      {/* Current Plan Status */}
      {currentPlan !== "free" && subStatus && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Current Subscription</h2>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className={`text-sm font-bold px-3 py-1 rounded-full capitalize ${PLANS.find((p) => p.id === currentPlan)?.badge ?? "bg-gray-700 text-gray-300"}`}>
                  {currentPlan} Plan
                </span>
                {subStatus.isOnTrial && (
                  <span className="text-xs bg-green-900/50 text-green-300 px-2 py-0.5 rounded-full">
                    Trial ends {new Date(subStatus.trialEndsAt!).toLocaleDateString()}
                  </span>
                )}
              </div>
              <p className="text-gray-400 text-sm">
                {subStatus.uploadsThisWeek} / {subStatus.price === 14.99 ? 2 : subStatus.price === 24.99 ? 4 : 7} uploads used this week
              </p>
              <p className="text-gray-600 text-xs mt-1">
                Resets {new Date(subStatus.weekResetAt).toLocaleDateString()}
              </p>
            </div>
            <button onClick={handleCancel} className="text-sm text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/40 px-3 py-1.5 rounded-lg transition-colors">
              Cancel Plan
            </button>
          </div>
        </div>
      )}

      {/* Plans */}
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">
          {currentPlan === "free" ? "Choose a Plan" : "Change Plan"}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {PLANS.map((plan) => {
            const isCurrent = plan.id === currentPlan;
            return (
              <div key={plan.id}
                className={`relative bg-gray-900 rounded-xl border p-5 transition-all ${isCurrent ? `${plan.border} ring-2 ${plan.ring}` : "border-gray-800 hover:border-gray-700"} ${plan.popular ? "scale-[1.02]" : ""}`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                    POPULAR
                  </div>
                )}
                {isCurrent && (
                  <div className="absolute -top-3 right-4 bg-green-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                    CURRENT
                  </div>
                )}
                <div className={`inline-block bg-gradient-to-r ${plan.color} text-white text-xs font-bold px-2.5 py-1 rounded-lg mb-3`}>
                  {plan.name}
                </div>
                <div className="mb-1">
                  <span className="text-3xl font-bold text-white">${plan.price}</span>
                  <span className="text-gray-400 text-sm">/mo</span>
                </div>
                {plan.trial && <p className="text-green-400 text-xs mb-3 font-medium">✓ {plan.trial}</p>}
                {!plan.trial && <div className="mb-3" />}
                <ul className="space-y-1.5 mb-4">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-gray-300 text-xs">
                      <span className="text-green-400">✓</span> {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => handleSelectPlan(plan.id)}
                  disabled={isCurrent}
                  className={`w-full py-2 rounded-lg text-sm font-semibold transition-all ${isCurrent ? "bg-gray-700 text-gray-500 cursor-default" : `bg-gradient-to-r ${plan.color} text-white hover:opacity-90`}`}
                >
                  {isCurrent ? "Current Plan" : currentPlan === "free" ? "Get Started" : "Switch Plan"}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* PayPal Payment Modal */}
      {showPayPal && selectedPlan && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">
                Subscribe to {PLANS.find((p) => p.id === selectedPlan)?.name}
              </h3>
              <button onClick={() => { setShowPayPal(false); setSelectedPlan(null); }}
                className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-gray-800 transition-colors">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="mb-4 p-3 bg-gray-800 rounded-lg">
              <p className="text-gray-300 text-sm">
                <span className="text-white font-semibold">{PLANS.find((p) => p.id === selectedPlan)?.name} Plan</span>
                {" — "}{PLANS.find((p) => p.id === selectedPlan)?.priceLabel}
              </p>
              {selectedPlan === "starter" && (
                <p className="text-green-400 text-xs mt-1">✓ Includes 3-day free trial</p>
              )}
            </div>
            <PayPalButton
              plan={selectedPlan}
              amount={PLANS.find((p) => p.id === selectedPlan)?.price ?? 0}
              onSuccess={handlePaymentSuccess}
              onError={() => toast.error("Payment failed. Please try again.")}
            />
            <p className="text-xs text-gray-600 text-center mt-3">
              Secured by PayPal · Cancel anytime
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
