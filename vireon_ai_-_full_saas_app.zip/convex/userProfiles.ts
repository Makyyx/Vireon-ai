import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getOrCreate = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    return profile;
  },
});

export const ensureProfile = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const existing = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (existing) return existing._id;
    const now = Date.now();
    const weekFromNow = now + 7 * 24 * 60 * 60 * 1000;
    return await ctx.db.insert("userProfiles", {
      userId,
      plan: "free",
      uploadsThisWeek: 0,
      weekResetAt: weekFromNow,
    });
  },
});

export const updatePlan = mutation({
  args: {
    plan: v.union(v.literal("free"), v.literal("starter"), v.literal("growth"), v.literal("pro")),
    paypalSubscriptionId: v.optional(v.string()),
    trialEndsAt: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (!profile) throw new Error("Profile not found");
    await ctx.db.patch(profile._id, {
      plan: args.plan,
      paypalSubscriptionId: args.paypalSubscriptionId,
      trialEndsAt: args.trialEndsAt,
    });
  },
});

export const getPlanLimits = query({
  args: { plan: v.union(v.literal("free"), v.literal("starter"), v.literal("growth"), v.literal("pro")) },
  handler: async (_ctx, args) => {
    const limits = {
      free: { uploadsPerWeek: 0, maxSeries: 0, label: "Free" },
      starter: { uploadsPerWeek: 2, maxSeries: 1, label: "Starter" },
      growth: { uploadsPerWeek: 4, maxSeries: 2, label: "Growth" },
      pro: { uploadsPerWeek: 7, maxSeries: 3, label: "Pro" },
    };
    return limits[args.plan];
  },
});
