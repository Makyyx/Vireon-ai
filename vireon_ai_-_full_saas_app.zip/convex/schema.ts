import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  userProfiles: defineTable({
    userId: v.id("users"),
    plan: v.union(v.literal("free"), v.literal("starter"), v.literal("growth"), v.literal("pro")),
    trialEndsAt: v.optional(v.number()),
    uploadsThisWeek: v.number(),
    weekResetAt: v.number(),
    paypalSubscriptionId: v.optional(v.string()),
    paypalOrderId: v.optional(v.string()),
  }).index("by_userId", ["userId"]),

  series: defineTable({
    userId: v.id("users"),
    title: v.string(),
    niche: v.string(),
    tone: v.string(),
    style: v.string(),
    voice: v.string(),
    episodeCount: v.number(),
    isActive: v.boolean(),
  }).index("by_userId", ["userId"]),

  content: defineTable({
    userId: v.id("users"),
    seriesId: v.optional(v.id("series")),
    title: v.string(),
    niche: v.string(),
    tone: v.string(),
    style: v.string(),
    voice: v.string(),
    script: v.object({
      hook: v.string(),
      body: v.string(),
      cliffhanger: v.string(),
    }),
    caption: v.string(),
    hashtags: v.array(v.string()),
    voiceoverText: v.string(),
    status: v.union(v.literal("draft"), v.literal("scheduled"), v.literal("published")),
    episodeNumber: v.optional(v.number()),
    generationStatus: v.optional(v.union(v.literal("pending"), v.literal("done"), v.literal("error"))),
  }).index("by_userId", ["userId"]).index("by_seriesId", ["seriesId"]),

  scheduledPosts: defineTable({
    userId: v.id("users"),
    contentId: v.id("content"),
    scheduledAt: v.number(),
    platform: v.string(),
    status: v.union(v.literal("pending"), v.literal("published"), v.literal("failed")),
  }).index("by_userId", ["userId"]).index("by_contentId", ["contentId"]).index("by_scheduledAt", ["scheduledAt"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
