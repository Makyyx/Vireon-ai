import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import PayPalButton from "../components/PayPalButton";
import { useTheme } from "../ThemeContext";

const PLANS = [
  {
    id: "starter" as const,
    name: "Starter",
    price: 14.99,
    priceLabel: "$14.99/mo",
    trial: "3-day free trial — no charge now",
    features: ["2 uploads per week", "1 active series", "AI script generation", "Caption & hashtags", "Voiceover text", "Video frame export"],
    color: "from-blue-500 to-blue-700",
    border: "border-blue-500/30",
    ring: "ring-blue-500/50",
    badge: "bg-blue-900/50 text-blue-300",
    badgeLight: "bg-blue-100 text-blue-700",
  },
  {
    id: "growth" as const,
    name: "Growth",
    price: 24.99,
    priceLabel: "$24.99/mo",
    trial: null,
    features: ["4 uploads per week", "2 active series", "AI script generation", "Caption & hashtags", "Voiceover text", "Video frame export"],
    color: "from-purple-500 to-purple-700",
    border: "border-purple-500/30",
    ring: "ring-purple-500/50",
    badge: "bg-purple-900/50 text-purple-300",
    badgeLight: "bg-purple-100 text-purple-700",
    popular: true,
  },
  {
    id: "pro" as const,
    name: "Pro",
    price: 34.99,
    priceLabel: "$34.99/mo",
    trial: null,
    features: ["Daily uploads (7/week)", "3 active series", "AI script generation", "Caption & hashtags", "Voiceover text", "Video frame export"],
    color: "from-yellow-500 to-orange-600",
    border: "border-yellow-500/30",
    ring: "ring-yellow-500/50",
    badge: "bg-yellow-900/50 text-yellow-300",
    badgeLight: "bg-yellow-100 text-yellow-700",
  },
];

export default function Settings() {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const user = useQuery(api.auth.loggedInUser);
  const profile = useQuery(api.userProfiles.getOrCreate);
  const subStatus = useQuery(api.payments.getSubscriptionStatus);
  const cancelSubscription = useMutation(api.payments.cancelSubscription);
  const startFreeTrial = useMutation(api.payments.startFreeTrial);

  const [selectedPlan, setSelectedPlan] = useState<"starter" | "growth" | "pro" | null>(null);
  const [showPayPal, setShowPayPal] = useState(false);
  const [startingTrial, setStartingTrial] = useState(false);

  const currentPlan = profile?.plan ?? "free";
  const hasUsedTrial = subStatus?.hasUsedTrial ?? false;

  const handleSelectPlan = (planId: "starter" | "growth" | "pro") => {
    if (planId === currentPlan && !subStatus?.isOnTrial) return;
    setSelectedPlan(planId);
    setShowPayPal(true);
  };

  const handleStartFreeTrial = async () => {
    setStartingTrial(true);
    try {
      await startFreeTrial();
      toast.success("🎉 Your 3-day free trial has started! No charge until the trial ends.");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to start trial");
    } finally {
      setStartingTrial(false);
    }
  };

  const handleCancel = async () => {
    if (!confirm("Cancel your subscription? You'll be downgraded to the free plan.")) return;
    try {
      await cancelSubscription();
      toast.success("Subscription cancelled");
    } catch {
      toast.error("Failed to cancel subscription");
    }
  };

  const handlePaymentSuccess = () => {
    setShowPayPal(false);
    setSelectedPlan(null);
    toast.success("🎉 Plan upgraded successfully!");
  };

  const card = isDark ? "bg-gray-900 border-gray-800" : "bg-white border-gray-200";
  const textPrimary = isDark ? "text-white" : "text-gray-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-500";
  const inputBg = isDark ? "bg-gray-800 border-gray-700 text-white" : "bg-gray-50 border-gray-300 text-gray-900";

  // Days remaining in trial
  const trialDaysLeft = subStatus?.trialEndsAt
    ? Math.max(0, Math.ceil((subStatus.trialEndsAt - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className={`text-3xl font-bold ${textPrimary} mb-1`}>Settings</h1>
        <p className={textSecondary}>Manage your account and subscription</p>
      </div>

      {/* Account Info */}
      <div className={`border ${card} rounded-xl p-6 mb-6`}>
        <h2 className={`text-lg font-semibold ${textPrimary} mb-4`}>Account</h2>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-xl font-bold text-white" aria-hidden="true">
            {user?.email?.[0]?.toUpperCase() ?? "U"}
          </div>
          <div>
            <p className={`font-medium ${textPrimary}`}>{user?.email ?? "—"}</p>
            <p className={`text-sm ${textSecondary}`}>Member since {user ? new Date(user._creationTime).toLocaleDateString() : "—"}</p>
          </div>
        </div>
      </div>

      {/* Trial Banner */}
      {subStatus?.isOnTrial && trialDaysLeft !== null && (
        <div className="mb-6 bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-500/30 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className={`font-semibold ${textPrimary}`}>🎉 Free Trial Active</p>
            <p className={`text-sm ${textSecondary}`}>
              {trialDaysLeft === 0
                ? "Trial ends today — add payment info to continue"
                : `${trialDaysLeft} day${trialDaysLeft !== 1 ? "s" : ""} remaining — you won't be charged until the trial ends`}
            </p>
          </div>
          <button
            onClick={() => { setSelectedPlan("starter"); setShowPayPal(true); }}
            className="bg-green-600 hover:bg-green-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors"
          >
            Add Payment Info
          </button>
        </div>
      )}

      {/* Current Plan Status */}
      {currentPlan !== "free" && subStatus && !subStatus.isOnTrial && (
        <div className={`border ${card} rounded-xl p-6 mb-6`}>
          <h2 className={`text-lg font-semibold ${textPrimary} mb-4`}>Current Subscription</h2>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className={`text-sm font-bold px-3 py-1 rounded-full capitalize ${isDark ? PLANS.find((p) => p.id === currentPlan)?.badge : PLANS.find((p) => p.id === currentPlan)?.badgeLight} ?? ""`}>
                  {currentPlan} Plan
                </span>
              </div>
              <p className={`text-sm ${textSecondary}`}>
                {subStatus.uploadsThisWeek} / {subStatus.price === 14.99 ? 2 : subStatus.price === 24.99 ? 4 : 7} uploads used this week
              </p>
              <p className={`text-xs mt-1 ${isDark ? "text-gray-600" : "text-gray-400"}`}>
                Resets {new Date(subStatus.weekResetAt).toLocaleDateString()}
              </p>
            </div>
            <button
              onClick={handleCancel}
              className="text-sm text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/40 px-3 py-1.5 rounded-lg transition-colors"
            >
              Cancel Plan
            </button>
          </div>
        </div>
      )}

      {/* Plans */}
      <div className="mb-6">
        <h2 className={`text-lg font-semibold ${textPrimary} mb-4`}>
          {currentPlan === "free" ? "Choose a Plan" : "Change Plan"}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {PLANS.map((plan) => {
            const isCurrent = plan.id === currentPlan;
            const isTrialPlan = plan.id === "starter" && subStatus?.isOnTrial;
            const canTrial = plan.id === "starter" && currentPlan === "free" && !hasUsedTrial;

            return (
              <div
                key={plan.id}
                className={`relative ${isDark ? "bg-gray-900" : "bg-white"} rounded-xl border p-5 transition-all ${
                  isCurrent ? `${plan.border} ring-2 ${plan.ring}` : isDark ? "border-gray-800 hover:border-gray-700" : "border-gray-200 hover:border-gray-300"
                } ${plan.popular ? "scale-[1.02]" : ""}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                    POPULAR
                  </div>
                )}
                {isCurrent && !isTrialPlan && (
                  <div className="absolute -top-3 right-4 bg-green-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                    CURRENT
                  </div>
                )}
                {isTrialPlan && (
                  <div className="absolute -top-3 right-4 bg-green-600 text-white text-xs font-bold px-3 py-1 rounded-full animate-pulse">
                    TRIAL
                  </div>
                )}
                <div className={`inline-block bg-gradient-to-r ${plan.color} text-white text-xs font-bold px-2.5 py-1 rounded-lg mb-3`}>
                  {plan.name}
                </div>
                <div className="mb-1">
                  <span className={`text-3xl font-bold ${textPrimary}`}>${plan.price}</span>
                  <span className={`text-sm ${textSecondary}`}>/mo</span>
                </div>
                {plan.trial && (
                  <p className="text-green-500 text-xs mb-3 font-medium">✓ {plan.trial}</p>
                )}
                {!plan.trial && <div className="mb-3" />}
                <ul className="space-y-1.5 mb-4">
                  {plan.features.map((f) => (
                    <li key={f} className={`flex items-center gap-2 text-xs ${isDark ? "text-gray-300" : "text-gray-600"}`}>
                      <span className="text-green-500" aria-hidden="true">✓</span> {f}
                    </li>
                  ))}
                </ul>

                {/* CTA buttons */}
                {canTrial ? (
                  <div className="space-y-2">
                    <button
                      onClick={handleStartFreeTrial}
                      disabled={startingTrial}
                      className="w-full py-2 rounded-lg text-sm font-semibold bg-green-600 hover:bg-green-500 disabled:opacity-50 text-white transition-all"
                    >
                      {startingTrial ? "Starting…" : "Start Free Trial"}
                    </button>
                    <button
                      onClick={() => handleSelectPlan(plan.id)}
                      className={`w-full py-2 rounded-lg text-sm font-medium transition-all border ${isDark ? "border-gray-700 text-gray-400 hover:text-white hover:border-gray-600" : "border-gray-300 text-gray-500 hover:text-gray-700"}`}
                    >
                      Subscribe Now
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => handleSelectPlan(plan.id)}
                    disabled={isCurrent && !isTrialPlan}
                    className={`w-full py-2 rounded-lg text-sm font-semibold transition-all ${
                      isCurrent && !isTrialPlan
                        ? isDark ? "bg-gray-700 text-gray-500 cursor-default" : "bg-gray-100 text-gray-400 cursor-default"
                        : `bg-gradient-to-r ${plan.color} text-white hover:opacity-90`
                    }`}
                  >
                    {isCurrent && !isTrialPlan
                      ? "Current Plan"
                      : isTrialPlan
                      ? "Add Payment Info"
                      : currentPlan === "free"
                      ? "Get Started"
                      : "Switch Plan"}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* PayPal Payment Modal */}
      {showPayPal && selectedPlan && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="payment-modal-title"
        >
          <div className={`${isDark ? "bg-gray-900 border-gray-700" : "bg-white border-gray-200"} border rounded-2xl p-6 w-full max-w-md shadow-2xl`}>
            <div className="flex items-center justify-between mb-4">
              <h3 id="payment-modal-title" className={`text-lg font-bold ${textPrimary}`}>
                {subStatus?.isOnTrial ? "Add Payment Info" : `Subscribe to ${PLANS.find((p) => p.id === selectedPlan)?.name}`}
              </h3>
              <button
                onClick={() => { setShowPayPal(false); setSelectedPlan(null); }}
                aria-label="Close payment dialog"
                className={`${textSecondary} hover:${textPrimary} p-1 rounded-lg ${isDark ? "hover:bg-gray-800" : "hover:bg-gray-100"} transition-colors`}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className={`mb-4 p-3 ${isDark ? "bg-gray-800" : "bg-gray-50"} rounded-lg`}>
              <p className={`text-sm ${textSecondary}`}>
                <span className={`font-semibold ${textPrimary}`}>{PLANS.find((p) => p.id === selectedPlan)?.name} Plan</span>
                {" — "}{PLANS.find((p) => p.id === selectedPlan)?.priceLabel}
              </p>
              {selectedPlan === "starter" && subStatus?.isOnTrial && (
                <p className="text-green-500 text-xs mt-1">✓ You won't be charged until your trial ends</p>
              )}
              {selectedPlan === "starter" && !subStatus?.isOnTrial && !hasUsedTrial && (
                <p className="text-green-500 text-xs mt-1">✓ 3-day free trial — first charge after trial ends</p>
              )}
            </div>
            <PayPalButton
              plan={selectedPlan}
              amount={PLANS.find((p) => p.id === selectedPlan)?.price ?? 0}
              onSuccess={handlePaymentSuccess}
              onError={() => toast.error("Payment failed. Please try again.")}
            />
            <p className={`text-xs ${isDark ? "text-gray-600" : "text-gray-400"} text-center mt-3`}>
              Secured by PayPal · Cancel anytime
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
