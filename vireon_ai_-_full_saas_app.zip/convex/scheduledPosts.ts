import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    const posts = await ctx.db
      .query("scheduledPosts")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .order("asc")
      .collect();

    return await Promise.all(
      posts.map(async (post) => {
        const content = await ctx.db.get(post.contentId);
        return { ...post, content };
      })
    );
  },
});

export const schedule = mutation({
  args: {
    contentId: v.id("content"),
    scheduledAt: v.number(),
    platform: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const content = await ctx.db.get(args.contentId);
    if (!content || content.userId !== userId) throw new Error("Content not found");

    await ctx.db.patch(args.contentId, { status: "scheduled" });

    return await ctx.db.insert("scheduledPosts", {
      userId,
      contentId: args.contentId,
      scheduledAt: args.scheduledAt,
      platform: args.platform,
      status: "pending",
    });
  },
});

export const deleteScheduled = mutation({
  args: { postId: v.id("scheduledPosts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const post = await ctx.db.get(args.postId);
    if (!post || post.userId !== userId) throw new Error("Not found");
    await ctx.db.patch(post.contentId, { status: "draft" });
    await ctx.db.delete(args.postId);
  },
});
