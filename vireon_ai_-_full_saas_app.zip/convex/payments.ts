import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const initiateSubscription = mutation({
  args: {
    plan: v.union(v.literal("starter"), v.literal("growth"), v.literal("pro")),
    paypalOrderId: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) throw new Error("Profile not found");

    const trialEndsAt = args.plan === "starter" ? Date.now() + 3 * 24 * 60 * 60 * 1000 : undefined;

    await ctx.db.patch(profile._id, {
      plan: args.plan,
      paypalOrderId: args.paypalOrderId,
      trialEndsAt,
    });

    return { success: true };
  },
});

export const cancelSubscription = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) throw new Error("Profile not found");

    await ctx.db.patch(profile._id, {
      plan: "free",
      paypalSubscriptionId: undefined,
      paypalOrderId: undefined,
      trialEndsAt: undefined,
    });

    return { success: true };
  },
});

export const getSubscriptionStatus = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (!profile) return null;

    const planPrices: Record<string, number> = { starter: 14.99, growth: 24.99, pro: 34.99 };

    return {
      plan: profile.plan,
      price: planPrices[profile.plan] ?? 0,
      trialEndsAt: profile.trialEndsAt,
      isOnTrial: profile.trialEndsAt ? Date.now() < profile.trialEndsAt : false,
      paypalSubscriptionId: profile.paypalSubscriptionId,
      uploadsThisWeek: profile.uploadsThisWeek,
      weekResetAt: profile.weekResetAt,
    };
  },
});
