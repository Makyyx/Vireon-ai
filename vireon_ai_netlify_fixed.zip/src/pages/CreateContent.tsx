import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";
import ContentViewer from "../components/ContentViewer";
import { Page } from "../App";
import { useTheme } from "../ThemeContext";

const NICHES = ["Horror", "Relationships", "Facts", "Motivation", "Comedy", "Finance", "Fitness", "Travel", "Tech", "Food"];
const TONES = ["Dramatic", "Funny", "Dark", "Inspirational", "Mysterious", "Energetic", "Calm", "Sarcastic"];
const STYLES = ["Gameplay", "Stock Footage", "AI Visuals", "Drawing/Animation", "Talking Head", "Text on Screen"];
const VOICES = ["Male", "Female", "Energetic", "Calm", "Deep", "Upbeat"];

export default function CreateContent({ setCurrentPage }: { setCurrentPage: (p: Page) => void }) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const profile = useQuery(api.userProfiles.getOrCreate);
  const seriesList = useQuery(api.series.list);
  const createContent = useMutation(api.content.create);

  const [title, setTitle] = useState("");
  const [niche, setNiche] = useState("Horror");
  const [tone, setTone] = useState("Dramatic");
  const [style, setStyle] = useState("Stock Footage");
  const [voice, setVoice] = useState("Male");
  const [seriesId, setSeriesId] = useState<Id<"series"> | "">("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContentId, setGeneratedContentId] = useState<Id<"content"> | null>(null);

  const plan = profile?.plan ?? "free";
  const planLimits: Record<string, number> = { free: 0, starter: 2, growth: 4, pro: 7 };
  const uploadsLeft = Math.max(0, (planLimits[plan] ?? 0) - (profile?.uploadsThisWeek ?? 0));

  const handleGenerate = async () => {
    if (!title.trim()) { toast.error("Please enter a title"); return; }
    if (plan === "free") { toast.error("Please upgrade your plan to generate content"); return; }
    if (uploadsLeft <= 0) { toast.error("Weekly upload limit reached. Resets next week."); return; }
    setIsGenerating(true);
    try {
      const contentId = await createContent({
        title: title.trim(), niche, tone, style, voice,
        seriesId: seriesId || undefined,
      });
      setGeneratedContentId(contentId);
      toast.success("Content generation started!");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to generate content");
    } finally {
      setIsGenerating(false);
    }
  };

  if (generatedContentId) {
    return (
      <ContentViewer
        contentId={generatedContentId}
        onBack={() => setGeneratedContentId(null)}
        onCreateNew={() => { setGeneratedContentId(null); setTitle(""); }}
        setCurrentPage={setCurrentPage}
      />
    );
  }

  const card = isDark ? "bg-gray-900 border-gray-800" : "bg-white border-gray-200";
  const textPrimary = isDark ? "text-white" : "text-gray-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-500";
  const inputCls = `w-full ${isDark ? "bg-gray-900 border-gray-700 text-white placeholder-gray-500" : "bg-white border-gray-300 text-gray-900 placeholder-gray-400"} border rounded-xl px-4 py-3 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-colors`;
  const chipActive = "bg-violet-600 text-white";
  const chipInactive = isDark ? "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900";

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className={`text-3xl font-bold ${textPrimary} mb-1`}>Create Content</h1>
        <p className={textSecondary}>Generate viral short-form video content with AI</p>
      </div>

      {plan === "free" && (
        <div className="mb-6 bg-gradient-to-r from-violet-900/40 to-purple-900/40 border border-violet-500/30 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className={`font-semibold ${textPrimary}`}>Upgrade to create content</p>
            <p className={`text-sm ${textSecondary}`}>Start with a 3-day free trial — no charge now</p>
          </div>
          <button onClick={() => setCurrentPage("settings")} className="bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
            Start Free Trial
          </button>
        </div>
      )}

      {plan !== "free" && (
        <div className={`mb-6 flex items-center gap-3 text-sm border ${card} rounded-xl p-3`}>
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" aria-hidden="true" />
          <span className={textSecondary}>{uploadsLeft} upload{uploadsLeft !== 1 ? "s" : ""} remaining this week</span>
          <span className={isDark ? "text-gray-600" : "text-gray-300"}>·</span>
          <span className={`${isDark ? "text-gray-500" : "text-gray-400"} capitalize`}>{plan} plan</span>
        </div>
      )}

      <div className="space-y-6">
        {/* Title */}
        <div>
          <label htmlFor="content-title" className={`block text-sm font-medium ${textSecondary} mb-2`}>Content Title</label>
          <input
            id="content-title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. The Haunted House on Elm Street"
            className={inputCls}
          />
        </div>

        {/* Niche */}
        <fieldset>
          <legend className={`block text-sm font-medium ${textSecondary} mb-2`}>Niche</legend>
          <div className="flex flex-wrap gap-2">
            {NICHES.map((n) => (
              <button key={n} onClick={() => setNiche(n)} aria-pressed={niche === n}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${niche === n ? chipActive : chipInactive}`}>
                {n}
              </button>
            ))}
          </div>
        </fieldset>

        {/* Tone */}
        <fieldset>
          <legend className={`block text-sm font-medium ${textSecondary} mb-2`}>Tone</legend>
          <div className="flex flex-wrap gap-2">
            {TONES.map((t) => (
              <button key={t} onClick={() => setTone(t)} aria-pressed={tone === t}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${tone === t ? chipActive : chipInactive}`}>
                {t}
              </button>
            ))}
          </div>
        </fieldset>

        {/* Style */}
        <fieldset>
          <legend className={`block text-sm font-medium ${textSecondary} mb-2`}>Visual Style</legend>
          <div className="flex flex-wrap gap-2">
            {STYLES.map((s) => (
              <button key={s} onClick={() => setStyle(s)} aria-pressed={style === s}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${style === s ? chipActive : chipInactive}`}>
                {s}
              </button>
            ))}
          </div>
        </fieldset>

        {/* Voice */}
        <fieldset>
          <legend className={`block text-sm font-medium ${textSecondary} mb-2`}>Voice Style</legend>
          <div className="flex flex-wrap gap-2">
            {VOICES.map((v) => (
              <button key={v} onClick={() => setVoice(v)} aria-pressed={voice === v}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${voice === v ? chipActive : chipInactive}`}>
                {v}
              </button>
            ))}
          </div>
        </fieldset>

        {/* Series (optional) */}
        {seriesList && seriesList.length > 0 && (
          <div>
            <label htmlFor="series-select" className={`block text-sm font-medium ${textSecondary} mb-2`}>
              Add to Series <span className={isDark ? "text-gray-500" : "text-gray-400"}>(optional)</span>
            </label>
            <select
              id="series-select"
              value={seriesId}
              onChange={(e) => setSeriesId(e.target.value as Id<"series"> | "")}
              className={`w-full ${isDark ? "bg-gray-900 border-gray-700 text-white" : "bg-white border-gray-300 text-gray-900"} border rounded-xl px-4 py-3 focus:outline-none focus:border-violet-500 transition-colors`}
            >
              <option value="">— Standalone content —</option>
              {seriesList.filter((s) => s.isActive).map((s) => (
                <option key={s._id} value={s._id}>{s.title} (Ep. {s.episodeCount + 1})</option>
              ))}
            </select>
          </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={isGenerating || plan === "free" || uploadsLeft <= 0}
          className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-all flex items-center justify-center gap-3 text-base shadow-lg shadow-violet-900/30"
        >
          {isGenerating ? (
            <>
              <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Generating…
            </>
          ) : (
            <>
              <span className="text-lg" aria-hidden="true">✦</span>
              Generate Content with AI
            </>
          )}
        </button>
      </div>
    </div>
  );
}
