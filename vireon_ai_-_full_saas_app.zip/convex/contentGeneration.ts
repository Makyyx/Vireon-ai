"use node";
import { v } from "convex/values";
import { internalAction } from "./_generated/server";
import { internal } from "./_generated/api";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const generateContent = internalAction({
  args: {
    contentId: v.id("content"),
    niche: v.string(),
    tone: v.string(),
    style: v.string(),
    voice: v.string(),
    title: v.string(),
    episodeNumber: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const episodeInfo = args.episodeNumber ? ` (Episode ${args.episodeNumber})` : "";
    const prompt = `You are a viral short-form video content creator. Create content for a ${args.niche} video${episodeInfo} titled "${args.title}".

Tone: ${args.tone}
Visual Style: ${args.style}
Voice Style: ${args.voice}

Generate a JSON response with exactly this structure:
{
  "script": {
    "hook": "An attention-grabbing opening line (1-2 sentences)",
    "body": "The main content (3-5 sentences)",
    "cliffhanger": "A compelling ending that makes viewers want more (1-2 sentences)"
  },
  "caption": "An engaging social media caption (2-3 sentences)",
  "hashtags": ["hashtag1", "hashtag2", "hashtag3", "hashtag4", "hashtag5", "hashtag6", "hashtag7", "hashtag8", "hashtag9", "hashtag10"],
  "voiceoverText": "The full script text optimized for text-to-speech voiceover"
}

Make it viral, engaging, and optimized for short-form video platforms like TikTok, Instagram Reels, and YouTube Shorts.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4.1-nano",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const raw = response.choices[0].message.content;
      if (!raw) throw new Error("No content generated");

      const parsed = JSON.parse(raw);

      await ctx.runMutation(internal.content.updateContent, {
        contentId: args.contentId,
        script: {
          hook: parsed.script?.hook ?? "",
          body: parsed.script?.body ?? "",
          cliffhanger: parsed.script?.cliffhanger ?? "",
        },
        caption: parsed.caption ?? "",
        hashtags: Array.isArray(parsed.hashtags) ? parsed.hashtags.map((h: string) => h.replace(/^#/, "")) : [],
        voiceoverText: parsed.voiceoverText ?? "",
      });
    } catch (err) {
      console.error("Content generation failed:", err);
      await ctx.runMutation(internal.content.markGenerationError, { contentId: args.contentId });
    }
  },
});
