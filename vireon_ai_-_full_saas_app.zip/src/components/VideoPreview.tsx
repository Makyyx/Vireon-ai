import { useRef, useState, useEffect } from "react";
import { Doc } from "../../convex/_generated/dataModel";

type Content = Doc<"content">;

const BG_STYLES = [
  { id: "dark", label: "Dark Gradient", bg: "#0f0f1a", accent: "#7c3aed" },
  { id: "horror", label: "Horror Red", bg: "#1a0000", accent: "#dc2626" },
  { id: "neon", label: "Neon Cyber", bg: "#000d1a", accent: "#06b6d4" },
  { id: "gold", label: "Gold Pro", bg: "#1a1200", accent: "#d97706" },
  { id: "nature", label: "Nature Green", bg: "#001a0a", accent: "#16a34a" },
];

export default function VideoPreview({ content }: { content: Content }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [bgStyle, setBgStyle] = useState(BG_STYLES[0]);
  const [currentSection, setCurrentSection] = useState<"hook" | "body" | "cliffhanger">("hook");
  const [isPlaying, setIsPlaying] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const sections: Array<{ key: "hook" | "body" | "cliffhanger"; label: string; text: string }> = [
    { key: "hook", label: "HOOK", text: content.script.hook },
    { key: "body", label: "BODY", text: content.script.body },
    { key: "cliffhanger", label: "CLIFFHANGER", text: content.script.cliffhanger },
  ];

  const drawFrame = (section: typeof sections[0], style: typeof BG_STYLES[0]) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;

    // Background gradient
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, style.bg);
    grad.addColorStop(1, style.accent + "33");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Grid lines
    ctx.strokeStyle = style.accent + "15";
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 40) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let y = 0; y < H; y += 40) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }

    // Top accent bar
    const barGrad = ctx.createLinearGradient(0, 0, W, 0);
    barGrad.addColorStop(0, style.accent);
    barGrad.addColorStop(1, style.accent + "00");
    ctx.fillStyle = barGrad;
    ctx.fillRect(0, 0, W, 4);

    // Section label badge
    ctx.fillStyle = style.accent + "33";
    ctx.beginPath();
    ctx.roundRect(30, 30, 120, 32, 8);
    ctx.fill();
    ctx.fillStyle = style.accent;
    ctx.font = "bold 13px Inter, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(section.label, 44, 51);

    // Title
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 18px Inter, sans-serif";
    ctx.textAlign = "center";
    const titleMaxW = W - 60;
    wrapText(ctx, content.title, W / 2, 110, titleMaxW, 24);

    // Divider
    ctx.strokeStyle = style.accent + "60";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(60, 145); ctx.lineTo(W - 60, 145);
    ctx.stroke();

    // Script text
    ctx.fillStyle = "#e5e7eb";
    ctx.font = "16px Inter, sans-serif";
    ctx.textAlign = "center";
    wrapText(ctx, section.text, W / 2, 185, W - 80, 26);

    // Bottom branding
    ctx.fillStyle = style.accent + "80";
    ctx.font = "bold 12px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("✦ VIREON AI", W / 2, H - 30);

    // Hashtags preview
    if (content.hashtags.length > 0) {
      ctx.fillStyle = style.accent + "99";
      ctx.font = "11px Inter, sans-serif";
      const tags = content.hashtags.slice(0, 4).map((h) => `#${h}`).join("  ");
      ctx.fillText(tags, W / 2, H - 50);
    }
  };

  function wrapText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
    const words = text.split(" ");
    let line = "";
    let currentY = y;
    for (const word of words) {
      const testLine = line + word + " ";
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && line !== "") {
        ctx.fillText(line.trim(), x, currentY);
        line = word + " ";
        currentY += lineHeight;
        if (currentY > 480) { ctx.fillText("…", x, currentY); break; }
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line.trim(), x, currentY);
  }

  useEffect(() => {
    const section = sections.find((s) => s.key === currentSection) ?? sections[0];
    drawFrame(section, bgStyle);
  }, [currentSection, bgStyle, content]);

  useEffect(() => {
    if (isPlaying) {
      let idx = sections.findIndex((s) => s.key === currentSection);
      intervalRef.current = setInterval(() => {
        idx = (idx + 1) % sections.length;
        setCurrentSection(sections[idx].key);
        if (idx === sections.length - 1) {
          setIsPlaying(false);
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      }, 3000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isPlaying]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement("a");
    link.download = `${content.title.replace(/\s+/g, "-").toLowerCase()}-${currentSection}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  };

  const handleDownloadAll = () => {
    sections.forEach((section, i) => {
      setTimeout(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        drawFrame(section, bgStyle);
        const link = document.createElement("a");
        link.download = `${content.title.replace(/\s+/g, "-").toLowerCase()}-${section.key}.png`;
        link.href = canvas.toDataURL("image/png");
        link.click();
        if (i === sections.length - 1) {
          const cur = sections.find((s) => s.key === currentSection) ?? sections[0];
          drawFrame(cur, bgStyle);
        }
      }, i * 300);
    });
  };

  return (
    <div className="space-y-4">
      {/* Background Style Picker */}
      <div>
        <p className="text-sm text-gray-400 mb-2">Background Style</p>
        <div className="flex gap-2 flex-wrap">
          {BG_STYLES.map((s) => (
            <button key={s.id} onClick={() => setBgStyle(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${bgStyle.id === s.id ? "border-violet-500 text-violet-300 bg-violet-900/30" : "border-gray-700 text-gray-400 hover:border-gray-600"}`}>
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Canvas Preview */}
      <div className="flex justify-center">
        <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-black/50 border border-gray-700" style={{ width: 360, height: 540 }}>
          <canvas ref={canvasRef} width={360} height={540} className="block" />
        </div>
      </div>

      {/* Section Controls */}
      <div className="flex gap-2 justify-center">
        {sections.map((s) => (
          <button key={s.key} onClick={() => { setIsPlaying(false); setCurrentSection(s.key); }}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${currentSection === s.key ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700"}`}>
            {s.label}
          </button>
        ))}
      </div>

      {/* Playback & Download */}
      <div className="flex gap-3">
        <button onClick={() => { setCurrentSection("hook"); setIsPlaying(true); }}
          disabled={isPlaying}
          className="flex-1 flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 disabled:opacity-50 text-white py-2.5 rounded-xl text-sm font-medium transition-colors">
          {isPlaying ? (
            <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Playing…</>
          ) : (
            <><span>▶</span> Preview Slideshow</>
          )}
        </button>
        <button onClick={handleDownload}
          className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white px-4 py-2.5 rounded-xl text-sm font-medium transition-colors">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Download Frame
        </button>
        <button onClick={handleDownloadAll}
          className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium transition-colors">
          All 3
        </button>
      </div>
      <p className="text-xs text-gray-600 text-center">Download individual frames or all 3 sections as PNG images</p>
    </div>
  );
}
