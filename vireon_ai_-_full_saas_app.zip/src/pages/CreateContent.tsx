import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";
import ContentViewer from "../components/ContentViewer";
import { Page } from "../App";

const NICHES = ["Horror", "Relationships", "Facts", "Motivation", "Comedy", "Finance", "Fitness", "Travel", "Tech", "Food"];
const TONES = ["Dramatic", "Funny", "Dark", "Inspirational", "Mysterious", "Energetic", "Calm", "Sarcastic"];
const STYLES = ["Gameplay", "Stock Footage", "AI Visuals", "Drawing/Animation", "Talking Head", "Text on Screen"];
const VOICES = ["Male", "Female", "Energetic", "Calm", "Deep", "Upbeat"];

export default function CreateContent({ setCurrentPage }: { setCurrentPage: (p: Page) => void }) {
  const profile = useQuery(api.userProfiles.getOrCreate);
  const seriesList = useQuery(api.series.list);
  const createContent = useMutation(api.content.create);

  const [title, setTitle] = useState("");
  const [niche, setNiche] = useState("Horror");
  const [tone, setTone] = useState("Dramatic");
  const [style, setStyle] = useState("Stock Footage");
  const [voice, setVoice] = useState("Male");
  const [seriesId, setSeriesId] = useState<Id<"series"> | "">("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContentId, setGeneratedContentId] = useState<Id<"content"> | null>(null);

  const plan = profile?.plan ?? "free";
  const planLimits: Record<string, number> = { free: 0, starter: 2, growth: 4, pro: 7 };
  const uploadsLeft = Math.max(0, (planLimits[plan] ?? 0) - (profile?.uploadsThisWeek ?? 0));

  const handleGenerate = async () => {
    if (!title.trim()) { toast.error("Please enter a title"); return; }
    if (plan === "free") { toast.error("Please upgrade your plan to generate content"); return; }
    if (uploadsLeft <= 0) { toast.error("Weekly upload limit reached. Resets next week."); return; }
    setIsGenerating(true);
    try {
      const contentId = await createContent({
        title: title.trim(), niche, tone, style, voice,
        seriesId: seriesId || undefined,
      });
      setGeneratedContentId(contentId);
      toast.success("Content generation started!");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to generate content");
    } finally {
      setIsGenerating(false);
    }
  };

  if (generatedContentId) {
    return (
      <ContentViewer
        contentId={generatedContentId}
        onBack={() => setGeneratedContentId(null)}
        onCreateNew={() => { setGeneratedContentId(null); setTitle(""); }}
        setCurrentPage={setCurrentPage}
      />
    );
  }

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-1">Create Content</h1>
        <p className="text-gray-400">Generate viral short-form video content with AI</p>
      </div>

      {plan === "free" && (
        <div className="mb-6 bg-gradient-to-r from-violet-900/40 to-purple-900/40 border border-violet-500/30 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-white font-semibold">Upgrade to create content</p>
            <p className="text-gray-400 text-sm">You need a paid plan to generate AI content</p>
          </div>
          <button onClick={() => setCurrentPage("settings")} className="bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
            Upgrade
          </button>
        </div>
      )}

      {plan !== "free" && (
        <div className="mb-6 flex items-center gap-3 text-sm bg-gray-900 border border-gray-800 rounded-xl p-3">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-gray-300">{uploadsLeft} upload{uploadsLeft !== 1 ? "s" : ""} remaining this week</span>
          <span className="text-gray-600">·</span>
          <span className="text-gray-500 capitalize">{plan} plan</span>
        </div>
      )}

      <div className="space-y-6">
        {/* Title */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Content Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. The Haunted House on Elm Street"
            className="w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-colors"
          />
        </div>

        {/* Niche */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Niche</label>
          <div className="flex flex-wrap gap-2">
            {NICHES.map((n) => (
              <button key={n} onClick={() => setNiche(n)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${niche === n ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"}`}>
                {n}
              </button>
            ))}
          </div>
        </div>

        {/* Tone */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Tone</label>
          <div className="flex flex-wrap gap-2">
            {TONES.map((t) => (
              <button key={t} onClick={() => setTone(t)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${tone === t ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"}`}>
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Style */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Visual Style</label>
          <div className="flex flex-wrap gap-2">
            {STYLES.map((s) => (
              <button key={s} onClick={() => setStyle(s)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${style === s ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"}`}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Voice */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Voice Style</label>
          <div className="flex flex-wrap gap-2">
            {VOICES.map((v) => (
              <button key={v} onClick={() => setVoice(v)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${voice === v ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"}`}>
                {v}
              </button>
            ))}
          </div>
        </div>

        {/* Series (optional) */}
        {seriesList && seriesList.length > 0 && (
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Add to Series <span className="text-gray-500">(optional)</span></label>
            <select
              value={seriesId}
              onChange={(e) => setSeriesId(e.target.value as Id<"series"> | "")}
              className="w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-violet-500 transition-colors"
            >
              <option value="">— Standalone content —</option>
              {seriesList.filter((s) => s.isActive).map((s) => (
                <option key={s._id} value={s._id}>{s.title} (Ep. {s.episodeCount + 1})</option>
              ))}
            </select>
          </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={isGenerating || plan === "free" || uploadsLeft <= 0}
          className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-all flex items-center justify-center gap-3 text-base shadow-lg shadow-violet-900/30"
        >
          {isGenerating ? (
            <>
              <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Generating…
            </>
          ) : (
            <>
              <span className="text-lg">✦</span>
              Generate Content with AI
            </>
          )}
        </button>
      </div>
    </div>
  );
}
