import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

const PLATFORM_ICONS: Record<string, string> = {
  "TikTok": "🎵",
  "Instagram Reels": "📸",
  "YouTube Shorts": "▶️",
  "Facebook Reels": "👥",
};

export default function ScheduledPosts() {
  const posts = useQuery(api.scheduledPosts.list);
  const deleteScheduled = useMutation(api.scheduledPosts.deleteScheduled);

  const handleDelete = async (postId: Id<"scheduledPosts">) => {
    if (!confirm("Remove this scheduled post?")) return;
    await deleteScheduled({ postId });
    toast.success("Scheduled post removed");
  };

  const pending = posts?.filter((p) => p.status === "pending") ?? [];
  const published = posts?.filter((p) => p.status === "published") ?? [];
  const failed = posts?.filter((p) => p.status === "failed") ?? [];

  const now = Date.now();
  const upcoming = pending.filter((p) => p.scheduledAt > now);
  const overdue = pending.filter((p) => p.scheduledAt <= now);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-1">Scheduled Posts</h1>
        <p className="text-gray-400">Manage your content queue across platforms</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {[
          { label: "Upcoming", value: upcoming.length, color: "text-blue-400", bg: "bg-blue-500/10" },
          { label: "Published", value: published.length, color: "text-green-400", bg: "bg-green-500/10" },
          { label: "Failed", value: failed.length, color: "text-red-400", bg: "bg-red-500/10" },
        ].map((stat) => (
          <div key={stat.label} className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center gap-4">
            <div className={`w-10 h-10 rounded-lg ${stat.bg} ${stat.color} flex items-center justify-center text-xl font-bold`}>
              {stat.value}
            </div>
            <p className="text-gray-400 text-sm">{stat.label}</p>
          </div>
        ))}
      </div>

      {posts?.length === 0 ? (
        <div className="text-center py-16 bg-gray-900 border border-gray-800 rounded-xl">
          <div className="text-5xl mb-4">📅</div>
          <p className="text-white font-semibold mb-1">No scheduled posts</p>
          <p className="text-gray-400 text-sm">Generate content and schedule it for posting</p>
        </div>
      ) : (
        <div className="space-y-6">
          {overdue.length > 0 && (
            <Section title="⚠️ Overdue" posts={overdue} onDelete={handleDelete} variant="overdue" />
          )}
          {upcoming.length > 0 && (
            <Section title="📅 Upcoming" posts={upcoming} onDelete={handleDelete} variant="upcoming" />
          )}
          {published.length > 0 && (
            <Section title="✅ Published" posts={published} onDelete={handleDelete} variant="published" />
          )}
          {failed.length > 0 && (
            <Section title="❌ Failed" posts={failed} onDelete={handleDelete} variant="failed" />
          )}
        </div>
      )}
    </div>
  );
}

type PostWithContent = {
  _id: Id<"scheduledPosts">;
  scheduledAt: number;
  platform: string;
  status: string;
  content?: { title?: string; niche?: string; tone?: string } | null;
};

function Section({
  title,
  posts,
  onDelete,
  variant,
}: {
  title: string;
  posts: PostWithContent[];
  onDelete: (id: Id<"scheduledPosts">) => void;
  variant: "upcoming" | "overdue" | "published" | "failed";
}) {
  const borderColors = {
    upcoming: "border-blue-500/20",
    overdue: "border-yellow-500/20",
    published: "border-green-500/20",
    failed: "border-red-500/20",
  };

  const badgeColors = {
    upcoming: "bg-blue-900/50 text-blue-300",
    overdue: "bg-yellow-900/50 text-yellow-300",
    published: "bg-green-900/50 text-green-300",
    failed: "bg-red-900/50 text-red-300",
  };

  return (
    <div>
      <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">{title}</h2>
      <div className="space-y-3">
        {posts.map((post) => {
          const date = new Date(post.scheduledAt);
          const isToday = new Date().toDateString() === date.toDateString();
          const isTomorrow = new Date(Date.now() + 86400000).toDateString() === date.toDateString();
          const dateLabel = isToday ? "Today" : isTomorrow ? "Tomorrow" : date.toLocaleDateString(undefined, { month: "short", day: "numeric" });

          return (
            <div key={post._id} className={`bg-gray-900 border ${borderColors[variant]} rounded-xl p-4 flex items-center gap-4`}>
              <div className="text-2xl">{PLATFORM_ICONS[post.platform] ?? "📱"}</div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-medium truncate">{post.content?.title ?? "Untitled"}</p>
                <p className="text-gray-500 text-sm capitalize">{post.content?.niche} · {post.content?.tone}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-sm font-medium text-white">{dateLabel}</p>
                <p className="text-xs text-gray-500">{date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${badgeColors[variant]}`}>
                  {post.platform}
                </span>
                {variant !== "published" && (
                  <button onClick={() => onDelete(post._id)} className="p-1.5 text-gray-600 hover:text-red-400 rounded-lg hover:bg-gray-800 transition-colors">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
