import { createRoot } from "react-dom/client";
import { ConvexAuthProvider } from "@convex-dev/auth/react";
import { ConvexReactClient } from "convex/react";
import "./index.css";
import App from "./App";

function ConfigError({ message }: { message: string }) {
  return (
    <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center p-6">
      <div className="max-w-xl w-full bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center font-bold">
            V
          </div>
          <div>
            <h1 className="text-xl font-bold">Vireon AI setup required</h1>
            <p className="text-sm text-gray-400">The site deployed, but a required environment variable is missing.</p>
          </div>
        </div>

        <div className="rounded-xl bg-gray-950 border border-gray-800 p-4 text-sm text-gray-300 space-y-3">
          <p>{message}</p>
          <div>
            <p className="font-semibold text-white mb-2">Add this in Netlify → Site configuration → Environment variables:</p>
            <code className="block rounded bg-black/40 px-3 py-2 text-violet-300">VITE_CONVEX_URL=https://your-project.convex.cloud</code>
          </div>
          <p className="text-gray-400">After saving the variable, redeploy the site.</p>
        </div>
      </div>
    </div>
  );
}

const convexUrl = import.meta.env.VITE_CONVEX_URL;
const rootEl = document.getElementById("root");

if (!rootEl) {
  throw new Error("Root element #root was not found.");
}

const root = createRoot(rootEl);

if (!convexUrl) {
  root.render(
    <ConfigError message="Missing VITE_CONVEX_URL. Without it, the frontend cannot connect to your Convex backend." />,
  );
} else {
  const convex = new ConvexReactClient(convexUrl);

  root.render(
    <ConvexAuthProvider client={convex}>
      <App />
    </ConvexAuthProvider>,
  );
}
