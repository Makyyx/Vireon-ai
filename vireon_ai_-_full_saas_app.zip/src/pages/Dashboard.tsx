import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Page } from "../App";

export default function Dashboard({ setCurrentPage }: { setCurrentPage: (p: Page) => void }) {
  const profile = useQuery(api.userProfiles.getOrCreate);
  const contentList = useQuery(api.content.list);
  const seriesList = useQuery(api.series.list);
  const scheduledPosts = useQuery(api.scheduledPosts.list);
  const user = useQuery(api.auth.loggedInUser);

  const planInfo: Record<string, { label: string; color: string; uploadsPerWeek: number; maxSeries: number; price: string; gradient: string }> = {
    free: { label: "Free", color: "text-gray-400", uploadsPerWeek: 0, maxSeries: 0, price: "$0", gradient: "from-gray-600 to-gray-700" },
    starter: { label: "Starter", color: "text-blue-400", uploadsPerWeek: 2, maxSeries: 1, price: "$14.99/mo", gradient: "from-blue-500 to-blue-700" },
    growth: { label: "Growth", color: "text-purple-400", uploadsPerWeek: 4, maxSeries: 2, price: "$24.99/mo", gradient: "from-purple-500 to-purple-700" },
    pro: { label: "Pro", color: "text-yellow-400", uploadsPerWeek: 7, maxSeries: 3, price: "$34.99/mo", gradient: "from-yellow-500 to-orange-600" },
  };

  const plan = profile?.plan ?? "free";
  const info = planInfo[plan];
  const uploadsLeft = Math.max(0, info.uploadsPerWeek - (profile?.uploadsThisWeek ?? 0));
  const uploadProgress = info.uploadsPerWeek > 0 ? ((profile?.uploadsThisWeek ?? 0) / info.uploadsPerWeek) * 100 : 0;

  const recentContent = contentList?.slice(0, 5) ?? [];
  const upcomingPosts = scheduledPosts?.filter((p) => p.status === "pending").slice(0, 3) ?? [];

  const stats = [
    {
      label: "Total Content",
      value: contentList?.length ?? 0,
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      ),
      color: "text-violet-400",
      bg: "bg-violet-500/10",
    },
    {
      label: "Active Series",
      value: seriesList?.filter((s) => s.isActive).length ?? 0,
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4" />
        </svg>
      ),
      color: "text-blue-400",
      bg: "bg-blue-500/10",
    },
    {
      label: "Scheduled Posts",
      value: scheduledPosts?.filter((p) => p.status === "pending").length ?? 0,
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      ),
      color: "text-green-400",
      bg: "bg-green-500/10",
    },
    {
      label: "Uploads Left",
      value: uploadsLeft,
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
        </svg>
      ),
      color: "text-yellow-400",
      bg: "bg-yellow-500/10",
    },
  ];

  const statusColors: Record<string, string> = {
    draft: "bg-gray-700 text-gray-300",
    scheduled: "bg-blue-900/50 text-blue-300",
    published: "bg-green-900/50 text-green-300",
    pending: "bg-yellow-900/50 text-yellow-300",
    done: "bg-green-900/50 text-green-300",
    error: "bg-red-900/50 text-red-300",
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-1">
          Welcome back{user?.email ? `, ${user.email.split("@")[0]}` : ""}! 👋
        </h1>
        <p className="text-gray-400">Here's what's happening with your content today.</p>
      </div>

      {/* Plan Banner */}
      {plan === "free" && (
        <div className="mb-6 bg-gradient-to-r from-violet-900/40 to-purple-900/40 border border-violet-500/30 rounded-xl p-4 flex items-center justify-between">
          <div>
            <p className="text-white font-semibold">You're on the Free plan</p>
            <p className="text-gray-400 text-sm">Upgrade to start generating viral content</p>
          </div>
          <button
            onClick={() => setCurrentPage("settings")}
            className="bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors"
          >
            Upgrade Now
          </button>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-gray-900 border border-gray-800 rounded-xl p-5">
            <div className={`w-10 h-10 rounded-lg ${stat.bg} ${stat.color} flex items-center justify-center mb-3`}>
              {stat.icon}
            </div>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
            <p className="text-sm text-gray-400">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Plan Card */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Your Plan</h2>
          <div className={`inline-flex items-center gap-2 bg-gradient-to-r ${info.gradient} text-white text-sm font-bold px-3 py-1.5 rounded-lg mb-4`}>
            {info.label} — {info.price}
          </div>
          {plan !== "free" && (
            <>
              <div className="mb-2 flex justify-between text-sm">
                <span className="text-gray-400">Weekly uploads</span>
                <span className="text-white font-medium">{profile?.uploadsThisWeek ?? 0} / {info.uploadsPerWeek}</span>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-2 mb-4">
                <div
                  className="bg-gradient-to-r from-violet-500 to-purple-500 h-2 rounded-full transition-all"
                  style={{ width: `${Math.min(uploadProgress, 100)}%` }}
                />
              </div>
              <p className="text-sm text-gray-400">{uploadsLeft} uploads remaining this week</p>
            </>
          )}
          {plan === "free" && (
            <p className="text-sm text-gray-400">Upgrade to start creating content</p>
          )}
          <button
            onClick={() => setCurrentPage("settings")}
            className="mt-4 w-full text-sm text-violet-400 hover:text-violet-300 border border-violet-500/30 hover:border-violet-500/60 rounded-lg py-2 transition-colors"
          >
            Manage Plan
          </button>
        </div>

        {/* Recent Content */}
        <div className="lg:col-span-2 bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Recent Content</h2>
            <button
              onClick={() => setCurrentPage("create")}
              className="text-sm text-violet-400 hover:text-violet-300 transition-colors"
            >
              + Create New
            </button>
          </div>
          {recentContent.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-4xl mb-3">✦</div>
              <p className="text-gray-400 text-sm">No content yet. Start creating!</p>
              <button
                onClick={() => setCurrentPage("create")}
                className="mt-3 bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors"
              >
                Create Content
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {recentContent.map((item) => (
                <div key={item._id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{item.title}</p>
                    <p className="text-xs text-gray-500 capitalize">{item.niche} · {item.tone}</p>
                  </div>
                  <div className="flex items-center gap-2 ml-3">
                    {item.generationStatus === "pending" && (
                      <span className="text-xs bg-yellow-900/50 text-yellow-300 px-2 py-0.5 rounded-full animate-pulse">Generating…</span>
                    )}
                    {item.generationStatus === "error" && (
                      <span className="text-xs bg-red-900/50 text-red-300 px-2 py-0.5 rounded-full">Error</span>
                    )}
                    <span className={`text-xs px-2 py-0.5 rounded-full capitalize ${statusColors[item.status]}`}>
                      {item.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Upcoming Scheduled Posts */}
      {upcomingPosts.length > 0 && (
        <div className="mt-6 bg-gray-900 border border-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Upcoming Scheduled Posts</h2>
            <button onClick={() => setCurrentPage("scheduled")} className="text-sm text-violet-400 hover:text-violet-300">
              View All
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {upcomingPosts.map((post) => (
              <div key={post._id} className="p-3 bg-gray-800/50 rounded-lg">
                <p className="text-sm font-medium text-white truncate">{post.content?.title ?? "Untitled"}</p>
                <p className="text-xs text-gray-500 mt-1">{post.platform} · {new Date(post.scheduledAt).toLocaleDateString()}</p>
                <p className="text-xs text-gray-600">{new Date(post.scheduledAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
