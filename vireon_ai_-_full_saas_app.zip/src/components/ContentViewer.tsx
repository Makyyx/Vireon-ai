import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { useState, useRef } from "react";
import { toast } from "sonner";
import { Page } from "../App";
import VideoPreview from "./VideoPreview";

const PLATFORMS = ["TikTok", "Instagram Reels", "YouTube Shorts", "Facebook Reels"];

export default function ContentViewer({
  contentId,
  onBack,
  onCreateNew,
  setCurrentPage,
}: {
  contentId: Id<"content">;
  onBack: () => void;
  onCreateNew: () => void;
  setCurrentPage: (p: Page) => void;
}) {
  const content = useQuery(api.content.get, { contentId });
  const schedulePost = useMutation(api.scheduledPosts.schedule);
  const deleteContent = useMutation(api.content.deleteContent);

  const [activeTab, setActiveTab] = useState<"script" | "caption" | "voiceover" | "video">("script");
  const [showScheduler, setShowScheduler] = useState(false);
  const [schedulePlatform, setSchedulePlatform] = useState("TikTok");
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("12:00");
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    toast.success(`${label} copied!`);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleSchedule = async () => {
    if (!scheduleDate) { toast.error("Please select a date"); return; }
    const scheduledAt = new Date(`${scheduleDate}T${scheduleTime}`).getTime();
    if (scheduledAt < Date.now()) { toast.error("Please select a future date/time"); return; }
    try {
      await schedulePost({ contentId, scheduledAt, platform: schedulePlatform });
      toast.success(`Scheduled for ${new Date(scheduledAt).toLocaleString()}`);
      setShowScheduler(false);
      setCurrentPage("scheduled");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to schedule");
    }
  };

  const handleDelete = async () => {
    if (!confirm("Delete this content?")) return;
    await deleteContent({ contentId });
    onBack();
  };

  if (!content) {
    return (
      <div className="p-8 flex flex-col items-center justify-center min-h-96">
        {content === undefined ? (
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border-2 border-violet-500 border-t-transparent animate-spin" />
            <p className="text-gray-400">Generating your content…</p>
            <p className="text-gray-600 text-sm">This usually takes 10–20 seconds</p>
          </div>
        ) : (
          <p className="text-gray-400">Content not found</p>
        )}
      </div>
    );
  }

  const isPending = content.generationStatus === "pending";
  const isError = content.generationStatus === "error";

  return (
    <div className="p-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-gray-400 hover:text-white transition-colors p-2 rounded-lg hover:bg-gray-800">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">{content.title}</h1>
            <p className="text-gray-500 text-sm capitalize">{content.niche} · {content.tone} · {content.style}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onCreateNew} className="text-sm text-violet-400 hover:text-violet-300 border border-violet-500/30 hover:border-violet-500/60 px-3 py-1.5 rounded-lg transition-colors">
            + New
          </button>
          <button onClick={handleDelete} className="text-sm text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/40 px-3 py-1.5 rounded-lg transition-colors">
            Delete
          </button>
        </div>
      </div>

      {isPending && (
        <div className="mb-6 bg-yellow-900/20 border border-yellow-500/30 rounded-xl p-4 flex items-center gap-3">
          <div className="w-5 h-5 rounded-full border-2 border-yellow-400 border-t-transparent animate-spin shrink-0" />
          <div>
            <p className="text-yellow-300 font-medium">Generating content…</p>
            <p className="text-yellow-600 text-sm">AI is crafting your viral script. This takes about 10–20 seconds.</p>
          </div>
        </div>
      )}

      {isError && (
        <div className="mb-6 bg-red-900/20 border border-red-500/30 rounded-xl p-4">
          <p className="text-red-300 font-medium">Generation failed</p>
          <p className="text-red-500 text-sm">There was an error generating your content. Please try again.</p>
        </div>
      )}

      {!isPending && !isError && (
        <>
          {/* Tabs */}
          <div className="flex gap-1 mb-6 bg-gray-900 border border-gray-800 rounded-xl p-1">
            {(["script", "caption", "voiceover", "video"] as const).map((tab) => (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium capitalize transition-all ${activeTab === tab ? "bg-violet-600 text-white" : "text-gray-400 hover:text-white"}`}>
                {tab === "video" ? "🎬 Video Preview" : tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {/* Script Tab */}
          {activeTab === "script" && (
            <div className="space-y-4">
              {[
                { label: "🪝 Hook", key: "hook", value: content.script.hook, color: "border-red-500/30 bg-red-900/10" },
                { label: "📖 Body", key: "body", value: content.script.body, color: "border-blue-500/30 bg-blue-900/10" },
                { label: "⚡ Cliffhanger", key: "cliffhanger", value: content.script.cliffhanger, color: "border-yellow-500/30 bg-yellow-900/10" },
              ].map(({ label, key, value, color }) => (
                <div key={key} className={`border ${color} rounded-xl p-5`}>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold text-gray-300">{label}</span>
                    <button onClick={() => copyToClipboard(value, label)}
                      className="text-xs text-gray-500 hover:text-gray-300 transition-colors flex items-center gap-1">
                      {copied === label ? "✓ Copied" : "Copy"}
                    </button>
                  </div>
                  <p className="text-white leading-relaxed">{value}</p>
                </div>
              ))}
              <button
                onClick={() => copyToClipboard(`${content.script.hook}\n\n${content.script.body}\n\n${content.script.cliffhanger}`, "Full Script")}
                className="w-full border border-gray-700 hover:border-gray-600 text-gray-400 hover:text-white py-2.5 rounded-xl text-sm transition-colors"
              >
                Copy Full Script
              </button>
            </div>
          )}

          {/* Caption Tab */}
          {activeTab === "caption" && (
            <div className="space-y-4">
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-semibold text-gray-300">Caption</span>
                  <button onClick={() => copyToClipboard(content.caption, "Caption")}
                    className="text-xs text-gray-500 hover:text-gray-300 transition-colors">
                    {copied === "Caption" ? "✓ Copied" : "Copy"}
                  </button>
                </div>
                <p className="text-white leading-relaxed">{content.caption}</p>
              </div>
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-semibold text-gray-300">Hashtags</span>
                  <button onClick={() => copyToClipboard(content.hashtags.map((h) => `#${h}`).join(" "), "Hashtags")}
                    className="text-xs text-gray-500 hover:text-gray-300 transition-colors">
                    {copied === "Hashtags" ? "✓ Copied" : "Copy All"}
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {content.hashtags.map((tag) => (
                    <span key={tag} className="bg-violet-900/30 text-violet-300 border border-violet-500/20 px-3 py-1 rounded-full text-sm">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Voiceover Tab */}
          {activeTab === "voiceover" && (
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-gray-300">Voiceover Script</span>
                <button onClick={() => copyToClipboard(content.voiceoverText, "Voiceover")}
                  className="text-xs text-gray-500 hover:text-gray-300 transition-colors">
                  {copied === "Voiceover" ? "✓ Copied" : "Copy"}
                </button>
              </div>
              <p className="text-white leading-relaxed whitespace-pre-wrap">{content.voiceoverText}</p>
              <div className="mt-4 p-3 bg-gray-800/50 rounded-lg">
                <p className="text-xs text-gray-500">💡 Paste this into ElevenLabs, Murf.ai, or any TTS tool to generate your voiceover audio.</p>
              </div>
            </div>
          )}

          {/* Video Preview Tab */}
          {activeTab === "video" && (
            <VideoPreview content={content} />
          )}

          {/* Schedule Button */}
          {!showScheduler ? (
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setShowScheduler(true)}
                className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                Schedule Post
              </button>
            </div>
          ) : (
            <div className="mt-6 bg-gray-900 border border-gray-800 rounded-xl p-5">
              <h3 className="text-white font-semibold mb-4">Schedule Post</h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Platform</label>
                  <select value={schedulePlatform} onChange={(e) => setSchedulePlatform(e.target.value)}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-violet-500">
                    {PLATFORMS.map((p) => <option key={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Date</label>
                  <input type="date" value={scheduleDate} onChange={(e) => setScheduleDate(e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-violet-500" />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Time</label>
                  <input type="time" value={scheduleTime} onChange={(e) => setScheduleTime(e.target.value)}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-violet-500" />
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={handleSchedule} className="flex-1 bg-violet-600 hover:bg-violet-500 text-white font-semibold py-2.5 rounded-lg transition-colors">
                  Confirm Schedule
                </button>
                <button onClick={() => setShowScheduler(false)} className="px-4 text-gray-400 hover:text-white border border-gray-700 rounded-lg transition-colors">
                  Cancel
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
