import { v } from "convex/values";
import { mutation, query, internalMutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    return await ctx.db
      .query("content")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .order("desc")
      .take(50);
  },
});

export const get = query({
  args: { contentId: v.id("content") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    const content = await ctx.db.get(args.contentId);
    if (!content || content.userId !== userId) return null;
    return content;
  },
});

export const create = mutation({
  args: {
    title: v.string(),
    niche: v.string(),
    tone: v.string(),
    style: v.string(),
    voice: v.string(),
    seriesId: v.optional(v.id("series")),
    episodeNumber: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.plan === "free") {
      throw new Error("Upgrade your plan to generate content");
    }

    const now = Date.now();
    if (now > profile.weekResetAt) {
      await ctx.db.patch(profile._id, { uploadsThisWeek: 0, weekResetAt: now + 7 * 24 * 60 * 60 * 1000 });
    }

    const planLimits: Record<string, number> = { starter: 2, growth: 4, pro: 7 };
    const limit = planLimits[profile.plan] ?? 0;

    if (profile.uploadsThisWeek >= limit) {
      throw new Error(`Weekly upload limit reached for your ${profile.plan} plan`);
    }

    const contentId = await ctx.db.insert("content", {
      userId,
      seriesId: args.seriesId,
      title: args.title,
      niche: args.niche,
      tone: args.tone,
      style: args.style,
      voice: args.voice,
      script: { hook: "", body: "", cliffhanger: "" },
      caption: "",
      hashtags: [],
      voiceoverText: "",
      status: "draft",
      episodeNumber: args.episodeNumber,
      generationStatus: "pending",
    });

    await ctx.db.patch(profile._id, { uploadsThisWeek: profile.uploadsThisWeek + 1 });

    await ctx.scheduler.runAfter(0, internal.contentGeneration.generateContent, {
      contentId,
      niche: args.niche,
      tone: args.tone,
      style: args.style,
      voice: args.voice,
      title: args.title,
      episodeNumber: args.episodeNumber,
    });

    return contentId;
  },
});

export const updateContent = internalMutation({
  args: {
    contentId: v.id("content"),
    script: v.object({
      hook: v.string(),
      body: v.string(),
      cliffhanger: v.string(),
    }),
    caption: v.string(),
    hashtags: v.array(v.string()),
    voiceoverText: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.contentId, {
      script: args.script,
      caption: args.caption,
      hashtags: args.hashtags,
      voiceoverText: args.voiceoverText,
      generationStatus: "done",
    });
  },
});

export const markGenerationError = internalMutation({
  args: { contentId: v.id("content") },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.contentId, { generationStatus: "error" });
  },
});

export const deleteContent = mutation({
  args: { contentId: v.id("content") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const content = await ctx.db.get(args.contentId);
    if (!content || content.userId !== userId) throw new Error("Not found");
    await ctx.db.delete(args.contentId);
  },
});
