import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";
import { Page } from "../App";
import { useTheme } from "../ThemeContext";

const NICHES = ["Horror", "Relationships", "Facts", "Motivation", "Comedy", "Finance", "Fitness", "Travel", "Tech", "Food"];
const TONES = ["Dramatic", "Funny", "Dark", "Inspirational", "Mysterious", "Energetic", "Calm", "Sarcastic"];
const STYLES = ["Gameplay", "Stock Footage", "AI Visuals", "Drawing/Animation", "Talking Head", "Text on Screen"];
const VOICES = ["Male", "Female", "Energetic", "Calm", "Deep", "Upbeat"];

export default function MySeries({ setCurrentPage }: { setCurrentPage: (p: Page) => void }) {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const profile = useQuery(api.userProfiles.getOrCreate);
  const seriesList = useQuery(api.series.list);
  const createSeries = useMutation(api.series.create);
  const toggleActive = useMutation(api.series.toggleActive);
  const deleteSeries = useMutation(api.series.deleteSeries);

  const [showCreate, setShowCreate] = useState(false);
  const [selectedSeries, setSelectedSeries] = useState<Id<"series"> | null>(null);
  const [title, setTitle] = useState("");
  const [niche, setNiche] = useState("Horror");
  const [tone, setTone] = useState("Dramatic");
  const [style, setStyle] = useState("Stock Footage");
  const [voice, setVoice] = useState("Male");
  const [isCreating, setIsCreating] = useState(false);

  const plan = profile?.plan ?? "free";
  const planLimits: Record<string, number> = { free: 0, starter: 1, growth: 2, pro: 3 };
  const maxSeries = planLimits[plan] ?? 0;
  const activeSeries = seriesList?.filter((s) => s.isActive).length ?? 0;

  const handleCreate = async () => {
    if (!title.trim()) { toast.error("Please enter a series title"); return; }
    setIsCreating(true);
    try {
      await createSeries({ title: title.trim(), niche, tone, style, voice });
      toast.success("Series created!");
      setShowCreate(false);
      setTitle("");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to create series");
    } finally {
      setIsCreating(false);
    }
  };

  const handleDelete = async (seriesId: Id<"series">) => {
    if (!confirm("Delete this series? Episodes will remain as standalone content.")) return;
    await deleteSeries({ seriesId });
    toast.success("Series deleted");
    if (selectedSeries === seriesId) setSelectedSeries(null);
  };

  const card = isDark ? "bg-gray-900 border-gray-800" : "bg-white border-gray-200";
  const textPrimary = isDark ? "text-white" : "text-gray-900";
  const textSecondary = isDark ? "text-gray-400" : "text-gray-500";
  const inputCls = `w-full ${isDark ? "bg-gray-800 border-gray-700 text-white placeholder-gray-500" : "bg-gray-50 border-gray-300 text-gray-900 placeholder-gray-400"} border rounded-xl px-4 py-3 focus:outline-none focus:border-violet-500 transition-colors`;
  const selectCls = `w-full ${isDark ? "bg-gray-800 border-gray-700 text-white" : "bg-gray-50 border-gray-300 text-gray-900"} border rounded-lg px-3 py-2 focus:outline-none focus:border-violet-500`;

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className={`text-3xl font-bold ${textPrimary} mb-1`}>My Series</h1>
          <p className={textSecondary}>Manage your content series and episodes</p>
        </div>
        {plan !== "free" && activeSeries < maxSeries && (
          <button onClick={() => setShowCreate(true)}
            className="bg-violet-600 hover:bg-violet-500 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            New Series
          </button>
        )}
      </div>

      {plan === "free" && (
        <div className="mb-6 bg-gradient-to-r from-violet-900/40 to-purple-900/40 border border-violet-500/30 rounded-xl p-5 flex items-center justify-between">
          <div>
            <p className={`font-semibold ${textPrimary}`}>Upgrade to create series</p>
            <p className={`text-sm ${textSecondary}`}>Series are available on Starter and above</p>
          </div>
          <button onClick={() => setCurrentPage("settings")} className="bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
            Upgrade
          </button>
        </div>
      )}

      {plan !== "free" && (
        <p className={`mb-4 text-sm ${textSecondary}`}>{activeSeries} / {maxSeries} active series used</p>
      )}

      {/* Create Form */}
      {showCreate && (
        <div className={`mb-6 border ${isDark ? "bg-gray-900 border-violet-500/30" : "bg-white border-violet-300"} rounded-xl p-6`}>
          <h2 className={`text-lg font-semibold ${textPrimary} mb-4`}>Create New Series</h2>
          <div className="space-y-4">
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)}
              placeholder="Series title…"
              aria-label="Series title"
              className={inputCls} />
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={`block text-xs ${textSecondary} mb-1`}>Niche</label>
                <select value={niche} onChange={(e) => setNiche(e.target.value)} className={selectCls}>
                  {NICHES.map((n) => <option key={n}>{n}</option>)}
                </select>
              </div>
              <div>
                <label className={`block text-xs ${textSecondary} mb-1`}>Tone</label>
                <select value={tone} onChange={(e) => setTone(e.target.value)} className={selectCls}>
                  {TONES.map((t) => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className={`block text-xs ${textSecondary} mb-1`}>Visual Style</label>
                <select value={style} onChange={(e) => setStyle(e.target.value)} className={selectCls}>
                  {STYLES.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className={`block text-xs ${textSecondary} mb-1`}>Voice</label>
                <select value={voice} onChange={(e) => setVoice(e.target.value)} className={selectCls}>
                  {VOICES.map((v) => <option key={v}>{v}</option>)}
                </select>
              </div>
            </div>
            <div className="flex gap-3">
              <button onClick={handleCreate} disabled={isCreating}
                className="flex-1 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white font-semibold py-2.5 rounded-xl transition-colors">
                {isCreating ? "Creating…" : "Create Series"}
              </button>
              <button onClick={() => setShowCreate(false)} className={`px-4 ${textSecondary} hover:${textPrimary} border ${isDark ? "border-gray-700" : "border-gray-300"} rounded-xl transition-colors`}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Series List */}
      {seriesList?.length === 0 ? (
        <div className={`text-center py-16 border ${card} rounded-xl`}>
          <div className="text-5xl mb-4" aria-hidden="true">🎬</div>
          <p className={`font-semibold ${textPrimary} mb-1`}>No series yet</p>
          <p className={`text-sm ${textSecondary} mb-4`}>Create a series to generate continuous episodes</p>
          {plan !== "free" && (
            <button onClick={() => setShowCreate(true)} className="bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
              Create First Series
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {seriesList?.map((series) => (
            <SeriesCard
              key={series._id}
              series={series}
              isSelected={selectedSeries === series._id}
              onSelect={() => setSelectedSeries(selectedSeries === series._id ? null : series._id)}
              onToggle={() => toggleActive({ seriesId: series._id })}
              onDelete={() => handleDelete(series._id)}
              setCurrentPage={setCurrentPage}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function SeriesCard({
  series,
  isSelected,
  onSelect,
  onToggle,
  onDelete,
  setCurrentPage,
}: {
  series: { _id: Id<"series">; title: string; niche: string; tone: string; style: string; voice: string; episodeCount: number; isActive: boolean };
  isSelected: boolean;
  onSelect: () => void;
  onToggle: () => void;
  onDelete: () => void;
  setCurrentPage: (p: Page) => void;
}) {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const episodes = useQuery(api.series.getEpisodes, { seriesId: series._id });

  const textPrimary = isDark ? "text-white" : "text-gray-900";
  const textSecondary = isDark ? "text-gray-500" : "text-gray-500";

  return (
    <div className={`${isDark ? "bg-gray-900" : "bg-white"} border rounded-xl overflow-hidden transition-all ${isSelected ? "border-violet-500/50" : isDark ? "border-gray-800 hover:border-gray-700" : "border-gray-200 hover:border-gray-300"}`}>
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className={`font-semibold truncate ${textPrimary}`}>{series.title}</h3>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${series.isActive ? isDark ? "bg-green-900/50 text-green-300" : "bg-green-100 text-green-700" : isDark ? "bg-gray-700 text-gray-400" : "bg-gray-100 text-gray-500"}`}>
                {series.isActive ? "Active" : "Paused"}
              </span>
            </div>
            <p className={`text-sm capitalize ${textSecondary}`}>{series.niche} · {series.tone} · {series.voice}</p>
          </div>
          <div className="flex items-center gap-1 ml-2">
            <button onClick={onToggle} className={`p-1.5 ${textSecondary} hover:${textPrimary} rounded-lg ${isDark ? "hover:bg-gray-800" : "hover:bg-gray-100"} transition-colors`} title={series.isActive ? "Pause series" : "Activate series"} aria-label={series.isActive ? "Pause series" : "Activate series"}>
              {series.isActive ? (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6" />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                </svg>
              )}
            </button>
            <button onClick={onDelete} className={`p-1.5 ${textSecondary} hover:text-red-400 rounded-lg ${isDark ? "hover:bg-gray-800" : "hover:bg-gray-100"} transition-colors`} aria-label="Delete series">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          </div>
        </div>

        <div className={`flex items-center gap-4 text-sm ${textSecondary} mb-3`}>
          <span>📺 {series.episodeCount} episodes</span>
          <span>🎨 {series.style}</span>
        </div>

        <button onClick={onSelect} className="text-xs text-violet-400 hover:text-violet-300 transition-colors">
          {isSelected ? "Hide episodes ▲" : "View episodes ▼"}
        </button>
      </div>

      {isSelected && (
        <div className={`border-t ${isDark ? "border-gray-800" : "border-gray-200"} p-4`}>
          <div className="flex items-center justify-between mb-3">
            <p className={`text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"}`}>Episodes</p>
            <button onClick={() => setCurrentPage("create")} className="text-xs text-violet-400 hover:text-violet-300 transition-colors">
              + Add Episode
            </button>
          </div>
          {episodes?.length === 0 ? (
            <p className={`text-sm text-center py-3 ${isDark ? "text-gray-600" : "text-gray-400"}`}>No episodes yet</p>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {episodes?.map((ep) => (
                <div key={ep._id} className={`flex items-center justify-between p-2 ${isDark ? "bg-gray-800/50" : "bg-gray-50"} rounded-lg`}>
                  <div>
                    <p className={`text-sm ${isDark ? "text-white" : "text-gray-900"}`}>{ep.episodeNumber ? `Ep. ${ep.episodeNumber}: ` : ""}{ep.title}</p>
                    <p className={`text-xs capitalize ${textSecondary}`}>{ep.status}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${ep.generationStatus === "done" ? isDark ? "bg-green-900/50 text-green-300" : "bg-green-100 text-green-700" : ep.generationStatus === "pending" ? isDark ? "bg-yellow-900/50 text-yellow-300 animate-pulse" : "bg-yellow-100 text-yellow-700 animate-pulse" : isDark ? "bg-gray-700 text-gray-400" : "bg-gray-100 text-gray-500"}`}>
                    {ep.generationStatus ?? "draft"}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
