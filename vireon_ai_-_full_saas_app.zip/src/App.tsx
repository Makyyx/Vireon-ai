import React from "react";
import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useEffect, useState } from "react";
import Dashboard from "./pages/Dashboard";
import CreateContent from "./pages/CreateContent";
import MySeries from "./pages/MySeries";
import ScheduledPosts from "./pages/ScheduledPosts";
import Settings from "./pages/Settings";

export type Page = "dashboard" | "create" | "series" | "scheduled" | "settings";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Authenticated>
        <AuthenticatedApp />
      </Authenticated>
      <Unauthenticated>
        <LandingPage />
      </Unauthenticated>
      <Toaster theme="dark" richColors position="top-right" />
    </div>
  );
}

function AuthenticatedApp() {
  const [currentPage, setCurrentPage] = useState<Page>("dashboard");
  const ensureProfile = useMutation(api.userProfiles.ensureProfile);

  useEffect(() => {
    ensureProfile();
  }, [ensureProfile]);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="flex-1 overflow-y-auto bg-gray-950">
        {currentPage === "dashboard" && <Dashboard setCurrentPage={setCurrentPage} />}
        {currentPage === "create" && <CreateContent setCurrentPage={setCurrentPage} />}
        {currentPage === "series" && <MySeries setCurrentPage={setCurrentPage} />}
        {currentPage === "scheduled" && <ScheduledPosts />}
        {currentPage === "settings" && <Settings />}
      </main>
    </div>
  );
}

function Sidebar({ currentPage, setCurrentPage }: { currentPage: Page; setCurrentPage: (p: Page) => void }) {
  const user = useQuery(api.auth.loggedInUser);
  const profile = useQuery(api.userProfiles.getOrCreate);

  const navItems: { id: Page; label: string; icon: React.ReactElement }[] = [
    {
      id: "dashboard", label: "Dashboard", icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
        </svg>
      )
    },
    {
      id: "create", label: "Create Content", icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      )
    },
    {
      id: "series", label: "My Series", icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4" />
        </svg>
      )
    },
    {
      id: "scheduled", label: "Scheduled Posts", icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      )
    },
    {
      id: "settings", label: "Settings", icon: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      )
    },
  ];

  const planColors: Record<string, string> = {
    free: "text-gray-400",
    starter: "text-blue-400",
    growth: "text-purple-400",
    pro: "text-yellow-400",
  };

  const planBadge: Record<string, string> = {
    free: "bg-gray-700 text-gray-300",
    starter: "bg-blue-900/50 text-blue-300",
    growth: "bg-purple-900/50 text-purple-300",
    pro: "bg-yellow-900/50 text-yellow-300",
  };

  return (
    <aside className="w-64 bg-gray-900 border-r border-gray-800 flex flex-col shrink-0">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-sm font-bold shadow-lg shadow-violet-900/40">
            V
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">
            Vireon AI
          </span>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setCurrentPage(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              currentPage === item.id
                ? "bg-violet-600/20 text-violet-300 border border-violet-500/30"
                : "text-gray-400 hover:text-white hover:bg-gray-800"
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-xs font-bold shrink-0">
            {user?.email?.[0]?.toUpperCase() ?? "U"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.email ?? "User"}</p>
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full capitalize ${planBadge[profile?.plan ?? "free"]}`}>
              {profile?.plan ?? "free"}
            </span>
          </div>
        </div>
        <SignOutButton />
      </div>
    </aside>
  );
}

function LandingPage() {
  const plans = [
    {
      name: "Starter",
      price: "$14.99",
      trial: "3-day free trial",
      features: ["2 uploads per week", "1 active series", "AI script generation", "Caption & hashtags", "Voiceover text"],
      color: "from-blue-500 to-blue-700",
      border: "border-blue-500/30",
      glow: "shadow-blue-900/20",
    },
    {
      name: "Growth",
      price: "$24.99",
      trial: null,
      features: ["4 uploads per week", "2 active series", "AI script generation", "Caption & hashtags", "Voiceover text"],
      color: "from-purple-500 to-purple-700",
      border: "border-purple-500/30",
      popular: true,
      glow: "shadow-purple-900/30",
    },
    {
      name: "Pro",
      price: "$34.99",
      trial: null,
      features: ["Daily uploads (7/week)", "3 active series", "AI script generation", "Caption & hashtags", "Voiceover text"],
      color: "from-yellow-500 to-orange-600",
      border: "border-yellow-500/30",
      glow: "shadow-yellow-900/20",
    },
  ];

  const features = [
    { icon: "✦", title: "AI Script Generation", desc: "Hook, body, and cliffhanger scripts optimized for virality" },
    { icon: "◷", title: "Smart Scheduling", desc: "Queue and schedule posts across platforms with ease" },
    { icon: "▶", title: "Series Management", desc: "Create continuous episode series with consistent branding" },
    { icon: "⚡", title: "Instant Captions", desc: "Auto-generated captions and hashtags for maximum reach" },
  ];

  return (
    <div className="min-h-screen bg-gray-950">
      <header className="border-b border-gray-800/60 px-6 py-4 flex items-center justify-between backdrop-blur-sm sticky top-0 z-10 bg-gray-950/80">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center text-sm font-bold">
            V
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">
            Vireon AI
          </span>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-6 py-20">
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 bg-violet-500/10 border border-violet-500/20 rounded-full px-4 py-2 text-violet-400 text-sm mb-6">
            ✦ AI-Powered Content Creation
          </div>
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-white via-violet-200 to-purple-400 bg-clip-text text-transparent leading-tight">
            Create Viral Content<br />with AI
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-10">
            Generate viral scripts, captions, hashtags, and voiceovers for short-form video content. Schedule and manage your content series effortlessly.
          </p>
          <div className="max-w-sm mx-auto bg-gray-900 border border-gray-800 rounded-2xl p-6 shadow-2xl">
            <SignInForm />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-20">
          {features.map((f) => (
            <div key={f.title} className="bg-gray-900/60 border border-gray-800 rounded-xl p-5 text-center">
              <div className="text-2xl mb-3 text-violet-400">{f.icon}</div>
              <h3 className="text-sm font-semibold text-white mb-1">{f.title}</h3>
              <p className="text-xs text-gray-500">{f.desc}</p>
            </div>
          ))}
        </div>

        <h2 className="text-3xl font-bold text-center text-white mb-10">Choose Your Plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative bg-gray-900 rounded-2xl border ${plan.border} p-6 shadow-xl ${plan.glow} ${plan.popular ? "ring-2 ring-purple-500/50 scale-105" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full">
                  MOST POPULAR
                </div>
              )}
              <div className={`inline-block bg-gradient-to-r ${plan.color} text-white text-sm font-bold px-3 py-1 rounded-lg mb-4`}>
                {plan.name}
              </div>
              <div className="mb-1">
                <span className="text-4xl font-bold text-white">{plan.price}</span>
                <span className="text-gray-400">/month</span>
              </div>
              {plan.trial && <p className="text-green-400 text-sm mb-4 font-medium">✓ {plan.trial}</p>}
              {!plan.trial && <div className="mb-4" />}
              <ul className="space-y-2">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-gray-300 text-sm">
                    <span className="text-green-400 font-bold">✓</span> {f}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
