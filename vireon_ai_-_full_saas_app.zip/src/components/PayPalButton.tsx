import { useEffect, useRef, useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

declare global {
  interface Window {
    paypal?: {
      Buttons: (config: {
        style?: object;
        createOrder: (data: unknown, actions: { order: { create: (o: object) => Promise<string> } }) => Promise<string>;
        onApprove: (data: { orderID: string }, actions: { order: { capture: () => Promise<unknown> } }) => Promise<void>;
        onError: (err: unknown) => void;
      }) => { render: (el: HTMLElement) => void };
    };
  }
}

export default function PayPalButton({
  plan,
  amount,
  onSuccess,
  onError,
}: {
  plan: "starter" | "growth" | "pro";
  amount: number;
  onSuccess: () => void;
  onError: () => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const initiateSubscription = useMutation(api.payments.initiateSubscription);
  const [loaded, setLoaded] = useState(false);
  const [sdkError, setSdkError] = useState(false);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    const clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID;
    if (!clientId) {
      setSdkError(true);
      return;
    }

    if (window.paypal) {
      setLoaded(true);
      return;
    }

    const script = document.createElement("script");
    script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=USD`;
    script.async = true;
    script.onload = () => setLoaded(true);
    script.onerror = () => setSdkError(true);
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  useEffect(() => {
    if (!loaded || !containerRef.current || !window.paypal) return;
    containerRef.current.innerHTML = "";

    window.paypal.Buttons({
      style: {
        layout: "vertical",
        color: "gold",
        shape: "rect",
        label: "pay",
      },
      createOrder: async (_data, actions) => {
        return actions.order.create({
          purchase_units: [{
            amount: { value: amount.toFixed(2), currency_code: "USD" },
            description: `Vireon AI ${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan`,
          }],
        });
      },
      onApprove: async (data, actions) => {
        setProcessing(true);
        try {
          await actions.order.capture();
          await initiateSubscription({ plan, paypalOrderId: data.orderID });
          onSuccess();
        } catch {
          onError();
        } finally {
          setProcessing(false);
        }
      },
      onError: () => {
        onError();
      },
    }).render(containerRef.current!);
  }, [loaded, plan, amount]);

  if (sdkError) {
    return (
      <div className="text-center py-4">
        <p className="text-yellow-400 text-sm mb-2">⚠️ PayPal not configured</p>
        <p className="text-gray-500 text-xs">Add <code className="bg-gray-800 px-1 rounded">VITE_PAYPAL_CLIENT_ID</code> to your <code className="bg-gray-800 px-1 rounded">.env.local</code> file to enable payments.</p>
      </div>
    );
  }

  if (processing) {
    return (
      <div className="flex items-center justify-center gap-3 py-6">
        <div className="w-5 h-5 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-gray-300">Processing payment…</p>
      </div>
    );
  }

  return (
    <div>
      {!loaded && (
        <div className="flex items-center justify-center gap-2 py-4 text-gray-400 text-sm">
          <div className="w-4 h-4 border-2 border-gray-500 border-t-transparent rounded-full animate-spin" />
          Loading PayPal…
        </div>
      )}
      <div ref={containerRef} />
    </div>
  );
}
