import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    return await ctx.db
      .query("series")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const get = query({
  args: { seriesId: v.id("series") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    const series = await ctx.db.get(args.seriesId);
    if (!series || series.userId !== userId) return null;
    return series;
  },
});

export const create = mutation({
  args: {
    title: v.string(),
    niche: v.string(),
    tone: v.string(),
    style: v.string(),
    voice: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.plan === "free") {
      throw new Error("Upgrade your plan to create series");
    }

    const planLimits: Record<string, number> = { starter: 1, growth: 2, pro: 3 };
    const maxSeries = planLimits[profile.plan] ?? 0;

    const existingSeries = await ctx.db
      .query("series")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .collect();

    const activeSeries = existingSeries.filter((s) => s.isActive);
    if (activeSeries.length >= maxSeries) {
      throw new Error(`Your ${profile.plan} plan allows only ${maxSeries} active series`);
    }

    return await ctx.db.insert("series", {
      userId,
      title: args.title,
      niche: args.niche,
      tone: args.tone,
      style: args.style,
      voice: args.voice,
      episodeCount: 0,
      isActive: true,
    });
  },
});

export const toggleActive = mutation({
  args: { seriesId: v.id("series") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const series = await ctx.db.get(args.seriesId);
    if (!series || series.userId !== userId) throw new Error("Not found");
    await ctx.db.patch(args.seriesId, { isActive: !series.isActive });
  },
});

export const deleteSeries = mutation({
  args: { seriesId: v.id("series") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const series = await ctx.db.get(args.seriesId);
    if (!series || series.userId !== userId) throw new Error("Not found");
    await ctx.db.delete(args.seriesId);
  },
});

export const getEpisodes = query({
  args: { seriesId: v.id("series") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    return await ctx.db
      .query("content")
      .withIndex("by_seriesId", (q) => q.eq("seriesId", args.seriesId))
      .order("asc")
      .collect();
  },
});

export const incrementEpisodeCount = mutation({
  args: { seriesId: v.id("series") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const series = await ctx.db.get(args.seriesId);
    if (!series || series.userId !== userId) throw new Error("Not found");
    await ctx.db.patch(args.seriesId, { episodeCount: series.episodeCount + 1 });
  },
});
